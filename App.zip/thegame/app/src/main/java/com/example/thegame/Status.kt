package com.example.thegame

enum class Status {
    Win,
    Lose,
    Tie
}