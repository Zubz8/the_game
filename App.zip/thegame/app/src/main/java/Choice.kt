enum class Choice {
    rock,
    paper,
    scissors,

}